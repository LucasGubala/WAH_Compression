Lucas Gubala
CS 351
WAH COMPRESSION

-To run WAHcompression.py, use the command line argument
python3 WAHcompression.py

The program will then create the files:
bitmapUnsorted.txt
bitmapSorted.txt
compressed32.txt
compressed32_sorted.txt
compressed64.txt
compressed64_sorted.txt